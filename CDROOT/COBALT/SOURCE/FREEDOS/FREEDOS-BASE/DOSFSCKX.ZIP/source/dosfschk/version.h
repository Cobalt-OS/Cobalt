#ifndef _version_h
#define _version_h

#define	VERSION		"2.11.DOS3"
#define VERSION_DATE	"8 Aug 2007"

#endif  /* _version_h */

