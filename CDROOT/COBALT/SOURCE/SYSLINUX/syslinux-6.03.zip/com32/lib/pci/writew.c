#define TYPE uint16_t
#define BWL(x) x ## w
#define BIOSCALL 0xb10c
#include "pci/writex.c"
