/* init code printf 			*/
/* simply include prf.c while defining  */
/* _INIT: reduces command line length   */
/* and simplifies make procedure	*/
#define _INIT 1
#include "prf.c"
