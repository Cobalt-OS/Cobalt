/*short drive[2];*/
enum boolean {true=1, false=0};
enum boolean checkdigests(md5_byte_t *, md5_byte_t *);
void PutString(char *);
