#ifndef FILE_EXISTS_H_
#define FILE_EXISTS_H_

BOOL LoFileNameExists(RDWRHandle handle, CLUSTER firstcluster,
                      char* filename, char* extension);

#endif
