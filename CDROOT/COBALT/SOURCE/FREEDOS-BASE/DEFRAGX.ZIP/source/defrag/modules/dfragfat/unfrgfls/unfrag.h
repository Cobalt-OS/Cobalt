#ifndef UNFRAGMENT_FILES_H_
#define UNFRAGMENT_FILES_H_

BOOL UnfragmentFiles(RDWRHandle handle);

#endif