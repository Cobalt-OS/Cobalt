#ifndef ISFILE_FRAGMENTED_H_
#define ISFILE_FRAGMENTED_H_

BOOL IsFileFragmented(RDWRHandle handle, CLUSTER firstclust);

#endif