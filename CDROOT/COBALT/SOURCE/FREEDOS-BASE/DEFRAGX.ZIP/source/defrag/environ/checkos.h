#ifndef CHECKOS_H_
#define CHECKOS_H_

char* CheckDefragEnvironment(void);

#endif
