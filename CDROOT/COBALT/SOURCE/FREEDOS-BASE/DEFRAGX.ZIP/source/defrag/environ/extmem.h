#ifndef EXTMEM_H_
#define EXTMEM_H_

unsigned GetExtendedMemorySize (void);

#endif
