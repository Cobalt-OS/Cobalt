#ifndef XMS_INSTALLED_H_
#define XMS_INSTALLED_H_

int IsXMSInstalled (void);

#endif
