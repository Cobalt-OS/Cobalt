#ifndef CHKARGS_H_
#define CHKARGS_H_

void ParseCmdLineArguments (int argc, char** argv, char optchar);

#endif
