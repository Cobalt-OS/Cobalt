#ifndef LOLOGMAN_H_
#define LOLOGMAN_H_

void cdecl ShowScreenPage(int page);
void cdecl PrintChar1(int asciichar);
void cdecl Scroll1Up(void);
void cdecl gotoxy1(int x, int y);

#endif
