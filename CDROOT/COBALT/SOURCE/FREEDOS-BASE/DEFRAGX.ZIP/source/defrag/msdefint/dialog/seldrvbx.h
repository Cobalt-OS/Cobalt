#ifndef SELDRVBX_H_
#define SELDRVBX_H_

char ShowDriveSelectionBox(void);

#endif
