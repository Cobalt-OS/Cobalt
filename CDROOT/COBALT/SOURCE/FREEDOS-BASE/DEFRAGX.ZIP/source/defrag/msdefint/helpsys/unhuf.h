#ifndef UNHUF_H_
#define UNHUF_H_

int UncompressBuffer(unsigned char* bufin, unsigned char* bufout);

#endif
