#ifndef KEEPDOS_H_
#define KEEPDOS_H_

void SaveDOSState(void);
void RestoreDOSState(void);

#endif
