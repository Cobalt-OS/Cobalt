#ifndef COPYRIGHT_H_
#define COPYRIGHT_H_

void ShowCopyRight(void);

#endif
