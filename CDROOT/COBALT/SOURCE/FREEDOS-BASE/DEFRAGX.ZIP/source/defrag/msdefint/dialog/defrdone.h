#ifndef DEFRAGMENTATION_DONE_DIALOG_H_
#define DEFRAGMENTATION_DONE_DIALOG_H_

int  ReportDefragDone(void);

/* Return codes. */
#define REBOOT_COMPUTER 0
#define EXIT_DEFRAG     1
#define CONTINUE_DEFRAG 2

#endif
