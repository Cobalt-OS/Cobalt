#ifndef FAT_SIZE_H_
#define FAT_SIZE_H_

int InspectFatLabelSize(void);

#endif
