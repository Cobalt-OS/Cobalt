#ifndef VERSION_INFO_H_
#define VERSION_INFO_H_

#define VERSION "beta 0.9.2"

#endif
