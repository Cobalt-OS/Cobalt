#ifndef LOW_DIRCOUNT_H_
#define LOW_DIRCOUNT_H_

long low_dircount(RDWRHandle handle, CLUSTER cluster, char attribute);

#endif

