#ifndef PATHCONVERSION_H_
#define PATHCONVERSION_H_

void ConvertUserPath(char* path, char* filename, char* extension);
void ConvertEntryPath(char* path, char* filename, char* extension);

#endif
