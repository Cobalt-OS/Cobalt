#ifndef NTH_FILE_CLUSTER_H_
#define NTH_FILE_CLUSTER_H_

CLUSTER GetNthFileCluster(RDWRHandle handle, CLUSTER firstclust, unsigned n,
                          BOOL* pasttheend);

                                 
#endif
