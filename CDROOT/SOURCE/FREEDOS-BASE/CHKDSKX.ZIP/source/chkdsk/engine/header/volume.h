#ifndef VOLUME_H_
#define VOLUME_H_

BOOL GetRootDirVolumeLabel(RDWRHandle handle,
                           struct DirectoryPosition* volumepos);

#endif
