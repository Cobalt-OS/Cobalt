#ifndef MAKE_ABSOLUTE_PATH_H_
#define MAKE_ABSOLUTE_PATH_H_

BOOL GetPreviousDir(char* direct);
BOOL MakeAbsolutePath(char* workingdir, char* relative, char* result);

#endif
