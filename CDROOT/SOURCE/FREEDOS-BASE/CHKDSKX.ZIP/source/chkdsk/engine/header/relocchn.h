#ifndef RELOC_CHN_H_
#define RELOC_CHN_H_

BOOL RelocateClusterChain(RDWRHandle handle, CLUSTER source, CLUSTER dest);

#endif
