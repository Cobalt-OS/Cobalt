#ifndef SUMMARY_H_
#define SUMMARY_H_

BOOL ReportVolumeSummary(RDWRHandle handle);

#endif
