#ifndef PATH_H_
#define PATH_H_

char *addsep(char *path);

#endif
