char *casefilename(char *s);
char *Truename(char *dst, char *src);
