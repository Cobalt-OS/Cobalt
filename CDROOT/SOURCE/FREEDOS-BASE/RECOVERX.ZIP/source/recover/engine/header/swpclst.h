#ifndef SWAP_CLUSTERS_H_
#define SWAP_CLUSTERS_H_

BOOL SwapClusters(RDWRHandle handle, CLUSTER clust1, CLUSTER clust2);

#endif
