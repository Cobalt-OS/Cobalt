#ifndef FREESPACE_H_
#define FREESPACE_H_

BOOL FindFirstFittingFreeSpace(RDWRHandle handle, 
                               unsigned long size,
                               CLUSTER* freespace);
                               
#endif
