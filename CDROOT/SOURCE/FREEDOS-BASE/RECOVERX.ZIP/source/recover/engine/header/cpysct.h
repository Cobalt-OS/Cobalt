#ifndef COPYSECTORS_H_
#define COPYSECTORS_H_

BOOL CopySectors(RDWRHandle handle, SECTOR source, SECTOR dest,
                 unsigned length);

#endif
