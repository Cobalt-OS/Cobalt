#ifndef FIND_CLUSTER_IN_FAT_H_
#define FIND_CLUSTER_IN_FAT_H_

BOOL FindClusterInFAT(RDWRHandle handle, CLUSTER tofind, CLUSTER* result);

#endif
