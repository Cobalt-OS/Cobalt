/* $Id: list.h,v 1.2 2002/08/30 21:32:21 perditionc Exp $ */

#ifndef _LIST_H
#define _LIST_H

dat_t *listbox(dat_t *dat_ary, int dat_count, char *fromdir);

#endif /* _BOX_H */
