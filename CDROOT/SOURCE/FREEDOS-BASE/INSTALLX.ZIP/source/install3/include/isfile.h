int
isfile (const char *filename);
