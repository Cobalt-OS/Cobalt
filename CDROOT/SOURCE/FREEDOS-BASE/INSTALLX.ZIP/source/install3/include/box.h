/* $Id: box.h,v 1.2 2002/08/30 21:32:21 perditionc Exp $ */

#ifndef _BOX_H
#define _BOX_H

void box (int x0, int y0, int x1, int y1);

#endif /* _BOX_H */
